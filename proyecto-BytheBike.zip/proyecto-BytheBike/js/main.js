window.onload = function(){
    //document.getElementById("btn-enviar").addEventListener("click", validar);
    //document.getElementById("btn-ruta").addEventListener("click", Ruta.validaruta);
document.getElementById("btn-ruta").addEventListener("click", crearuta);
    
  
}

    function validar(){

        /*cambiará a falso cnd no se cumpla*/
        var correcto = true;
        var nombre = document.getElementById('contacto-nombre').value;
        var mail = document.getElementById('contacto-email').value;
        var cuerpo = document.getElementById('contacto-cuerpo').value;
        
        /*validar campos*/
        
        if(nombre.length == 0 ){
            correcto = false;
            document.getElementById('contacto-nombre').style.border = "3px solid red";
            document.getElementById('p-nombre').innerHTML = "*Debes escribir un nombre";
            document.getElementById('p-nombre').style.color = "red";
        }
        
        if(mail.length == " " ){
            correcto = false;
            document.getElementById('contacto-email').style.border = "3px solid red";
            document.getElementById('p-email').innerHTML = "*Debes escribir un mail";
            document.getElementById('p-email').style.color = "red";
        }
        
        if(cuerpo.length == " " ){
            correcto = false;
            document.getElementById('contacto-cuerpo').style.border = "3px solid red";
            document.getElementById('p-cuerpo').innerHTML = "*Debes escribir un comentario";
            document.getElementById('p-cuerpo').style.color = "red";
        }
        
        /*si no está todo bien generaremos una alerta advirtiendo al usuario de que algunos datos no son los que esperamos.*/
        if(!correcto){
        alert('Algunos campos no están correctos, vuelva a revisarlos');
        }
        
        return correcto;
        }
    
    ;

function sinfoco(){

    var nombre = document.getElementById('contacto-nombre').value;
    var mail = document.getElementById('contacto-email').value;
    var cuerpo = document.getElementById('contacto-cuerpo').value;

    if(nombre.length != 0 ){
        correcto = false;
        document.getElementById('contacto-nombre').style.border = "";
        document.getElementById('p-nombre').innerHTML = " ";
    }
    if(mail.length != 0 ){
        correcto = false;
        document.getElementById('contacto-email').style.border = "";
        document.getElementById('p-email').innerHTML = " ";
    }
    if(cuerpo.length != 0 ){
        correcto = false;
        document.getElementById('contacto-cuerpo').style.border = "";
        document.getElementById('p-cuerpo').innerHTML = " ";
    }
}

    "use strict";//ECMASCRIPT
 
class Ruta {
    constructor(distancia, tiempo, dirección, disponibilidad) {
        this.distancia = distancia;
        this.tiempo = tiempo;
        this.dirección = dirección;
        this.disponibilidad = disponibilidad;
    }
    //Métodos
    validaruta(){
       
        //Validando el combo select
        
        if(this.distancia == ""){
            alert('Debe Elegir una distancia!');
            return false;
        }
        
        if(this.tiempo == ""){
            alert('Debe Elegir un tiempo!');
            return false;
        }
        
        if(this.disponibilidad == ""){
            alert('Debe Elegir una disponibilidad!');
            return false;
        }
    
        //obteniendo el valor que se puso en el campo text del formulario
        
        //la condición
        if (this.direccion == ""){
            alert('El campo dirección está vacio!');
            return false;
        }
       
        return true;
    }
    
}

function crearuta(){

    var distancia = document.getElementById('distancia').value;
    var tiempo = document.getElementById('tiempo').value;
    var disponibilidad = document.getElementById('disponibilidad').value;
    var direccion = document.getElementById('direccion').value;
    //objeto Ruta
    var rutaUsuario = new Ruta(distancia,tiempo,direccion,disponibilidad);

    almacenaruta(rutaUsuario);

}

//almacena los datos del formulario en un array
function almacenaruta(ruta){
    
    var arrayRutas = [];
    if(ruta.validaruta()){
        arrayRutas[0]=ruta;
    }
    console.log(arrayRutas);
  }








  